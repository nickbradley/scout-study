import { getTradeById } from "../src/find.js";
import { trades } from "./trades";
import { toBeNil } from 'jest-extended';
expect.extend({ toBeNil });

describe("getTradeById()", () => {
    it("Should find the specified trade.", () => {
        let transaction = getTradeById(trades, 5);
        if (Array.isArray(transaction)) {
            expect(transaction).toHaveLength(1);
            transaction = transaction[0];
        }
        expect(transaction).toStrictEqual(trades[2]);
    });
    it("Should return undefined or [] if no trade has id.", () => {
        const transaction = getTradeById(trades, -1);
        if (Array.isArray(transaction)) {
            expect(transaction).toHaveLength(0);
        } else {
            expect(transaction).toBeNil();
        }
    });
    it("Should return undefined or [] if there are no trades.", () => {
        const transaction = getTradeById([], 1);
        if (Array.isArray(transaction)) {
            expect(transaction).toHaveLength(0);
        } else {
            expect(transaction).toBeNil();
        }
    });
})