/**
 * Converts a number to a string with the appropriate
 * currency symbol (e.g., "$") formatted
 * according to the specified locale (e.g., "en-US").
 * @param {number} amount - The quantity of currency to print
 * @param {string} locale - The locale (e.g., "en-US") in
 * which to format the currency consiting of the 
 * two-letter language code (e.g., "en"), a hypen, and the
 * two-letter country code (e.g., "US").
 * @param {string} currency - An ISO 4217 currency code
 * (e.g., "USD").
 * @returns {string} A formatted string of the amount
 * represented in the local currency.
 */
export function printCurrency(amount, locale, currency) {

    // TODO: Generate a string representation as the amount
    // of currency formatted according to the locale.
    
    const x = amount.toLocaleString(locale, { style: 'currency', currency: currency });


    return x;
}