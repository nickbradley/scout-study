import moment from "moment";

/**
 * Returns a subset of trades between the specified past date
 * and the current date, inclusive.
 * @param {import("./trade").Trade[]} trades 
 * @param {number} from - When to start returning trades from
 * before the current date.
 * @param {"days"|"months"|"years"} unit - The time unit
 * representing the time to go back.
 * @returns {import("./trade").Trade[]} A filtered list of trades 
 */
export function getPastTradesFrom(trades, interval, unit = "days") {
    const endDate = new Date();

    // Currently, the startDate equals the endDate.
    // TODO: Update the startDate by subtracting the amount 
    // of time specified by the "interval" and "unit" parameters.  
    // const startDate = moment(endDate)
    const startDate = moment(endDate).subtract(interval, unit)


    return trades.filter((trade) => {
        const tradeDate = moment(trade.date);
        return tradeDate.isBetween(
            moment(startDate), moment(endDate), undefined, "[]"
        );
    });
}