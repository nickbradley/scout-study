import { printCurrency } from "../src/currency.js";

describe("printCurrency()", () => {

    it("Should format amount as Yen in en-US locale", () => {
        const result = printCurrency(50, "en-US", "JPY");
        expect(result).toBe("¥50");
    });

    it("Should format amount as sterling in en-UK locale", () => {
        const result = printCurrency(5000, "en-UK", "GBP");
        expect(result).toBe("£5,000.00");
    });

    it("Should format amount as sterling in fr-FR locale", () => {
        const result = printCurrency(5000, "fr-FR", "GBP");
        expect(result).toBe("5 000,00\u00A0£GB");
    });
});