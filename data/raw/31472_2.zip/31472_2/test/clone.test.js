import { cloneTradeLedger } from "../src/clone";
import { TradeType } from "../src/trade.js";

describe("cloneTradeLedger()", () => {
    it("Should create a copy of the trades", () => {
        const trades = [
            {
                id: 4,
                stockSymbol: "TSLA",
                shareCount: 3,
                sharePrice: 29.39,
                tradeType: TradeType.Sell,
                date: new Date(2021, 1, 4)
            },
            {
                id: 1,
                stockSymbol: "AAPL",
                shareCount: 10,
                sharePrice: 19.78,
                tradeType: TradeType.Buy,
                date: new Date(2022, 3, 2)
            },
            {
                id: 5,
                stockSymbol: "INTC",
                shareCount: 23,
                sharePrice: 243.98,
                tradeType: TradeType.Buy,
                date: new Date(2021, 1, 23)
            },
            {
                id: 2,
                stockSymbol: "TSLA",
                shareCount: 43,
                sharePrice: 22.00,
                tradeType: TradeType.Buy,
                date: new Date(2020, 12, 27)
            },
            {
                id: 6,
                stockSymbol: "AMZN",
                shareCount: 8,
                sharePrice: 61.00,
                tradeType: TradeType.Buy,
                date: new Date(2021, 2, 3)
            },
            {
                id: 3,
                stockSymbol: "AAPL",
                shareCount: 6,
                sharePrice: 21.00,
                tradeType: TradeType.Buy,
                date: new Date(2021, 1, 4)
            },
        ]
        const clone = cloneTradeLedger(trades);
        expect(clone).not.toBe(trades);  // check references are different
        expect(clone).toStrictEqual(trades);  // check values are the same
    });
    it("Should create a copy of an empty list of the trades ledger", () => {
        const trades = [];
        const clone = cloneTradeLedger(trades);
        expect(clone).not.toBe(trades);
        expect(clone).toStrictEqual(trades);
    });
});