import { sumTradedShares } from "../src/tutorial";
import { trades } from "./trades";

describe("simplifyTrade", () => {
    it("Should sum shareCount from all trades.", () => {
        const total = sumTradedShares(trades);
        expect(total).toBe(98); 
    });
    it("Should return the shareCount for a single trade.", () => {
        const total = sumTradedShares([trades[0]]);
        expect(total).toBe(8);
    })
    it("Should return 0 when there are no trades.", () => {
        const total = sumTradedShares([]);
        expect(total).toBe(0);
    })
})