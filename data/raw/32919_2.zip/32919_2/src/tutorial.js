
// Example Trade object for reference.
const exampleTrade = {
    id: 1,
    date: new Date(),
    stockSymbol: "APPL",
    shareCount: 4,
    sharePrice: 25.00,
    tradeType: "buy"
}

/**
 * Computes the total number of shares that have been traded
 * (both bought and sold).
 * @param {import("./trade").Trade[]} trades - A list of trades. 
 * @returns {number} The sum of "shareCount" across all trades.
 */
export function sumTradedShares(trades) {
    return trades.reduce((accum,item) => accum + item.shareCount, 0);
}