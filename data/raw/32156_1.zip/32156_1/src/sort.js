/**
 * Sorts trades by the number of shares transferred with 
 * larger transfers shown first.
 * @param {import("./trade").Trade[]} trades - List of trades
 * to be sorted.
 * @returns {import("./trade").Trade[]} - The trades sorted
 * with the trades having the largest share count first 
 * (descending order).
 */
export function sortTradesByShareCount(trades) {

    // TODO: Pass a comparison function to sort which compares
    // two trades, ordering the trade with the larger 
    // shareCount first (descending order).
    return trades.sort((a, b) => {
        if (a.shareCount <= b.shareCount) return 1
        else return -1
    });
}