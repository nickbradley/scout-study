import { getPastTradesFrom } from "../src/recent.js";
import { TradeType } from "../src/trade.js";

const year = 2020;
const month = 3;  // zero-based index
const day = 3;

function makeTrades() {
    return [
        {
            id: 1,
            stockSymbol: "AAPL",
            shareCount: 10,
            sharePrice: 19.78,
            tradeType: TradeType.Buy,
            date: new Date()
        },
        {
            id: 2,
            stockSymbol: "TSLA",
            shareCount: 43,
            sharePrice: 22.00,
            tradeType: TradeType.Buy,
            date: new Date(year, month - 1, 27) // 7 days prior
        },
        {
            id: 3,
            stockSymbol: "AAPL",
            shareCount: 6,
            sharePrice: 21.00,
            tradeType: TradeType.Buy,
            date: new Date(year, month - 1, 4)  // 30 days prior + DST
        },
        {
            id: 4,
            stockSymbol: "TSLA",
            shareCount: 3,
            sharePrice: 29.39,
            tradeType: TradeType.Sell,
            date: new Date(year, month - 1, day) // 1 month prior + DST
        },
        {
            id: 5,
            stockSymbol: "INTC",
            shareCount: 23,
            sharePrice: 243.98,
            tradeType: TradeType.Buy,
            date: new Date(year, month - 1, day - 3) // After 1 month prior + DST
        },
        {
            id: 6,
            stockSymbol: "AMZN",
            shareCount: 8,
            sharePrice: 61.00,
            tradeType: TradeType.Buy,
            date: new Date(year - 1, month, day) // 1 year prior
        },
    ];
}

describe("getPastTradesFrom()", () => {
    let trades = [];

    beforeAll(() => {
        jest.useFakeTimers('modern');
        jest.setSystemTime(new Date(year, month, day));
        trades = makeTrades();
    });

    afterAll(() => {
        jest.useRealTimers();
    });

    it("Should filter trades in the past 7 days.", () => {
        const tx = getPastTradesFrom(trades, 7);
        expect(tx).toEqual(
            expect.arrayContaining([
                expect.objectContaining({ id: 1 }),
                expect.objectContaining({ id: 2 })
            ])
        );
    });
    it("Should filter trades in the past 30 days.", () => {
        const tx = getPastTradesFrom(trades, 30, "days");
        expect(tx).toEqual(
            expect.arrayContaining([
                expect.objectContaining({ id: 1 }),
                expect.objectContaining({ id: 2 }),
                expect.objectContaining({ id: 3 })
            ])
        );
    })
    it("Should filter trades in the past month.", () => {
        const tx = getPastTradesFrom(trades, 1, "months");
        expect(tx).toEqual(
            expect.arrayContaining([
                expect.objectContaining({ id: 1 }),
                expect.objectContaining({ id: 2 }),
                expect.objectContaining({ id: 3 }),
                expect.objectContaining({ id: 4 })
            ])
        );
    });
    it("Should fitler trades when from value exceeds unit.", () => {
        const tx = getPastTradesFrom(trades, 32, "days");
        expect(tx).toEqual(
            expect.arrayContaining([
                expect.objectContaining({ id: 1 }),
                expect.objectContaining({ id: 2 }),
                expect.objectContaining({ id: 3 }),
                expect.objectContaining({ id: 4 })
            ])
        );
    });
})