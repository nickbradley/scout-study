/**
 * Converts a number to a string with the appropriate
 * currency symbol (e.g., "$") formatted
 * according to the specified locale (e.g., "en-US").
 * @param {number} amount - The quantity of currency to print
 * @param {string} locale - The locale (e.g., "en-US") in
 * which to format the currency consiting of the 
 * two-letter language code (e.g., "en"), a hypen, and the
 * two-letter country code (e.g., "US").
 * @param {string} currency - An ISO 4217 currency code
 * (e.g., "USD").
 * @returns {string} A formatted string of the amount
 * represented in the local currency.
 */
export function printCurrency(amount, locale, currency) {

    const formatter = new Intl.NumberFormat(locale, {
        style: 'currency',
        currency: currency,
      
        // These options are needed to round to whole numbers if that's what you want.
        //minimumFractionDigits: 0, // (this suffices for whole numbers, but will print 2500.10 as $2,500.1)
        //maximumFractionDigits: 0, // (causes 2500.99 to be printed as $2,501)
      });

      return formatter.format(amount);
}