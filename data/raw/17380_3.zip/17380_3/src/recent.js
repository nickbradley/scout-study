import moment from "moment";

/**
 * Returns a subset of trades between the specified past date
 * and the current date, inclusive.
 * @param {import("./trade").Trade[]} trades 
 * @param {number} from - When to start returning trades from
 * before the current date.
 * @param {"days"|"months"|"years"} unit - The time unit
 * representing the time to go back.
 * @returns {import("./trade").Trade[]} A filtered list of trades 
 */
export function getPastTradesFrom(trades, interval, unit = "days") {
    const endDate = new Date();

    // Currently, the startDate equals the endDate.
    // TODO: Update the startDate by subtracting the amount 
    // of time specified by the "interval" and "unit" parameters.  
    const startDate = moment(endDate)
   
    if (unit == "months") {
        startDate = subtractMonths(endDate,interval);
    }
    else if (unit == "years") {
        startDate = subtractYears(endDate,interval);
    }
    else if (unit == "days") {
        startDate.setDate(endDate-interval);
    }
    let yest = "Yesterday :: " + moment(selectedDate, "America/Chicago").subtract(1, 'days').format('DD-MM-YYYY') + " " + "00:00:00"; // getting invalid date
    return trades.filter((trade) => {
        const tradeDate = moment(trade.date);
        return tradeDate.isBetween(
            moment(startDate), moment(endDate), undefined, "[]"
        );
    });
}

function subtractMonths(date, months) {
    date.setMonth(date.getMonth() - months);
    return date;
  }

  function subtractYears(date, years) {
    date.setFullYear(date.getFullYear() - years);
    return date;
  }