import { sortTradesByShareCount } from "../src/sort.js";
import { trades } from "./trades";

describe("sortTradesByShareCount()", () => {
    it("Should sort the shareCount property in descending order.", () => {
        const sorted = sortTradesByShareCount(trades);
        expect(sorted.map(s => s.shareCount)).toStrictEqual([43, 23, 10, 8, 8, 6]);
    });
})