export const TradeType = {
    Sell: 0,
    Buy: 1
}

/**
 * An object representing the transfer of shares of stock between a trader and the market.
 * @typedef {Object} Trade
 * @property {number} id - The globally unique identifier for the trade in the market.
 * @property {Date} date - When the trade occurred.
 * @property {string} stockSymbol - The symbol of the traded stock.
 * @property {number} shareCount - The number of shares that were traded.
 * @property {number} sharePrice - The market price of each share of stock at the time of the transaction. 
 * @property {TradeType} tradeType - Indicates whether the stock shares were bought or sold.
 */

