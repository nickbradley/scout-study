/**
 * Duplicates the trades array to avoid side-effects when
 * using mutating operations (e.g., deletion).
 * @param {import("./trade").Trade[]} trades - The list of
 * trades to be cloned.
 * @returns {import("./trade").Trade[]} - The cloned copy of
 * trades.
 */
export function cloneTradeLedger(trades) {
    
    // TODO: Create a copy of the given trades and return it.
    // A shallow copy is acceptable.
    trades = [...trades];
    return trades;
}