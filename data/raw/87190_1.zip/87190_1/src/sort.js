/**
 * Sorts trades by the number of shares transferred with 
 * larger transfers shown first.
 * @param {import("./trade").Trade[]} trades - List of trades
 * to be sorted.
 * @returns {import("./trade").Trade[]} - The trades sorted
 * with the trades having the largest share count first 
 * (descending order).
 */
export function sortTradesByShareCount(trades) {

    // TODO: Pass a comparison function to sort which compares
    // two trades, ordering the trade with the larger 
    // shareCount first (descending order).
    return trades.sort(sort_by('shareCount', true, parseInt));
}

const sort_by = (field, reverse, primer) => {
    const key = primer ?
        function(x) {
            return primer(x[field])
        } :
        function(x) {
            return x[field]
        };
    reverse = !reverse ? 1 : -1;

    return function(a, b) {
        return a = key(a), b = key(b), reverse * ((a > b) - (b > a))
    }
}