import express from "express";
import path from "path";

/**
 * `app` is an instance of an express web server which handles
 * requests to registered routes.
 */
export const app = express();
let router = require('../src/public');
function setup() {
    //let router = require('../src/public');
    // TODO: Add a '/static' route which serves files from
    // src/public/

    app.use('/static', __dirname + '../src/public');
    //app.use(express.static(__dirname + router));
}

setup();