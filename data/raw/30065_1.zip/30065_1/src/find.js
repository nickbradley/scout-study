/**
 * Finds a single trade whose id matches the specified id.
 * @param {import("./trade").Trade[]} trades - A list of trades.
 * @param {number} id - The id of the trade.
 * @returns {import("./trade").Trade} - The trade whose id 
 * matches the id specified, or undefined (or []) if no 
 * trade has the specified id.
 */
export function getTradeById(trades, id) {

    // TODO: Find the trade with the specified id by 
    // checking for id === trade.id. If there is no trade 
    // with the given id, set to undefined or [].

    return trades.filter((el) => el.id === id) || [];
}