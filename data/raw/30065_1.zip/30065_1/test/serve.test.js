import request from "supertest";
import { app } from "../src/serve";

describe("Trade server", () => {
    it("should have a /static route", async () => {
        const res = await request(app).get("/static");
        expect(res.status).not.toEqual(404);
    });

    it("should serve files at /static from src/public/", async () => {
        const req = request(app);
        const response = await req.get("/static/receipt.pdf");
        expect(response.status).toEqual(200);
    }); 
});