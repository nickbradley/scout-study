/**
 * Finds a single trade whose id matches the specified id.
 * @param {import("./trade").Trade[]} trades - A list of trades.
 * @param {number} id - The id of the trade.
 * @returns {import("./trade").Trade} - The trade whose id 
 * matches the id specified, or undefined (or []) if no 
 * trade has the specified id.
 */
export function getTradeById(trades, id) {

    for (var x = 0; x < trades.length; x++){
        if(trades[x].id == id){
            return trades[x];
        }
    }

    return undefined;
}