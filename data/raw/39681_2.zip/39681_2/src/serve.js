import express from "express";
import path from "path";

/**
 * `app` is an instance of an express web server which handles
 * requests to registered routes.
 */
export const app = express();

function setup() {
    // Define `/files` route first
        app.use("/files", function (req, res) {
    return res.send("I will be served instead of a files directory");
  });
  
  // Static
  app.use("/", express.static('src/public'));
    // TODO: Add a '/static' route which serves files from
    // src/public/
}

// My js experience is in webdev and minor so I just dont really know what the question is asking sorry :(


setup();