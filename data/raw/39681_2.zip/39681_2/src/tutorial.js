
// Example Trade object for reference.
const exampleTrade = {
    id: 1,
    date: new Date(),
    stockSymbol: "APPL",
    shareCount: 4,
    sharePrice: 25.00,
    tradeType: "buy"
}

/**
 * Computes the total number of shares that have been traded
 * (both bought and sold).
 * @param {import("./trade").Trade[]} trades - A list of trades. 
 * @returns {number} The sum of "shareCount" across all trades.
 */
export function sumTradedShares(trades) {

    var totalcount = 0;

    for(var x = 0; x < trades.length; x++){
        totalcount += trades[x].shareCount;
    }

    return totalcount;
}