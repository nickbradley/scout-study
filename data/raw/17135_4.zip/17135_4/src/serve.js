import express from "express";
import path from "path";

/**
 * `app` is an instance of an express web server which handles
 * requests to registered routes.
 */
export const app = express();

function setup() {
    
    // TODO: Add a '/static' route which serves files from
    // src/public/
    app.get('/src/public', express.static(process.cwd() + '/static'));
}

setup();